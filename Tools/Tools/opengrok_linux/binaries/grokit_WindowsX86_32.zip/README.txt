Usage: grokit.exe [options]

Options:
  -h, --help       show this help message and exit
  --ppath=PPATH    Path to the location of source that should be cross-
                   referenced
                   NOTE: Each directory inside this will be considered as a
                   opengrok project
                   So, if you want single project, make sure that PPATH has
                   only one child directory that contains all source files
  --action=ACTION  Action to be performed.  Can be one of (setup|start|stop):
                   - setup: Setup opengrok for the project source present at
                   PPATH.
                   - start: Start the tomcat server
                   - stop:  Stop the tomcat server

The primary purpose of this tool is to help you setup OpenGrok *quickly*
Typical Usage:
    1. Setup opengrok for a project
    grokit.exe --ppath=<path to project source> --action=setup

    2. Start/Stop Tomcat server
    grokit.exe --action=start
    grokit.exe --action=stop

    Please send your comments / suggestions to raghu.sesha@gmail.com

NOTES:

1. All generated files are stored under the directory grokit_files.  
   
   You will loose all cross-referenced project details if you delete this

2. grokit uses port 8080 by default.  Not configurable as of now

3. Do not keep multiple copies of grokit for indexing.  
   
   This may cause unexpected behaviour.
